ZIPNAME=${1:?}

zip ww2ogg$ZIPNAME.zip Bit_stream.h codebook.cpp codebook.h COPYING crc.c crc.h errors.h hist.txt Makefile Makefile.common Makefile.mingw packed_codebooks.bin packed_codebooks_aoTuV_603.bin ww2ogg.cpp ww2ogg.exe wwriff.cpp wwriff.h zip.sh README
